Found on an old Mitac XT Turbo
T8 sets the machine to 8mhz
T5 sets the machine to 4.77mhz